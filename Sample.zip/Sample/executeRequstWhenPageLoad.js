

//window.addEventListener("load", myMain, false);

//function myMain(evt) {

//    var xMLHttpRequest = new XMLHttpRequest();

//    xMLHttpRequest.open('GET', "http://localhost:37156/api/TopicOrientations?url=bla");

//    xMLHttpRequest.responseType = 'json';


//    xMLHttpRequest.onload = function () {
//        var response = xMLHttpRequest.response;
//        alert('5');
//    }
//    xMLHttpRequest.send();

//}



//var xMLHttpRequest = new XMLHttpRequest();
//alert('1');
//xMLHttpRequest.open('GET', "http://localhost:37156/api/TopicOrientations?url=bla");
//alert('2');
//xMLHttpRequest.responseType = 'json';
//alert('3');
//xMLHttpRequest.onload = function () {
//    var response = xMLHttpRequest.response;
//    alert('6');
//}
//xMLHttpRequest.send();
//alert('4');

